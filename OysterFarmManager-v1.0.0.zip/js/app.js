const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);
const state={lang:localStorage.getItem("ofm_lang")||"ar",dark:localStorage.getItem("ofm_dark")==="1",history:JSON.parse(localStorage.getItem("ofm_history")||"[]")};
const t={
ar:{subtitle:"إدارة مزرعة المحار",welcome:"لوحة التحكم",heroText:"إدارة بسيطة وسريعة لمراحل تربية المحار.",statOystersLabel:"المحارات الحالية",statBagsLabel:"الجيوب المطلوبة",statTablesLabel:"الطاولات المطلوبة",statMortLabel:"النفوق",goCalc:"حاسبة التقسيم",goCalcSub:"الجيوب والطاولات",goMort:"حاسبة النفوق",goMortSub:"الخسائر والنسبة",goHistory:"السجل",goHistorySub:"آخر العمليات",goSettings:"الإعدادات",goSettingsSub:"اللغة والواجهة",calcTitle:"حاسبة التقسيم",calcDesc:"احسب الجيوب والطاولات المطلوبة.",oystersLabel:"عدد المحارات المتبقية",bagLabel:"المحارات في الجيب",tableLabel:"الجيوب في الطاولة",calcBtn:"احسب الآن",mortTitle:"حاسبة النفوق",mortDesc:"احسب الفاقد ونسبة النفوق.",initialLabel:"العدد عند البداية",currentLabel:"العدد الحالي",mortBtn:"احسب النفوق",historyTitle:"السجل",historyDesc:"آخر الحسابات المحفوظة على الجهاز.",clear:"مسح السجل",settingsTitle:"الإعدادات",settingsDesc:"تخصيص التطبيق.",languageLabel:"اللغة",version:"الإصدار 1.0.0",offline:"يعمل بدون إنترنت بعد التثبيت",navHome:"الرئيسية",navCalc:"الحساب",navHistory:"السجل",navSettings:"الإعدادات",bags:"الجيوب المطلوبة",tables:"الطاولات المطلوبة",capacity:"سعة الطاولة",lost:"المحارات المفقودة",rate:"نسبة النفوق",saved:"تم حفظ العملية",empty:"لا توجد عمليات محفوظة.",confirm:"هل تريد مسح السجل؟"},
fr:{subtitle:"Gestion de ferme ostréicole",welcome:"Tableau de bord",heroText:"Gestion simple et rapide de l’élevage des huîtres.",statOystersLabel:"Huîtres actuelles",statBagsLabel:"Poches nécessaires",statTablesLabel:"Tables nécessaires",statMortLabel:"Mortalité",goCalc:"Calculateur",goCalcSub:"Poches et tables",goMort:"Mortalité",goMortSub:"Pertes et taux",goHistory:"Historique",goHistorySub:"Dernières opérations",goSettings:"Paramètres",goSettingsSub:"Langue et interface",calcTitle:"Calculateur de répartition",calcDesc:"Calculez les poches et les tables nécessaires.",oystersLabel:"Huîtres restantes",bagLabel:"Huîtres par poche",tableLabel:"Poches par table",calcBtn:"Calculer",mortTitle:"Calculateur de mortalité",mortDesc:"Calculez les pertes et le taux de mortalité.",initialLabel:"Nombre initial",currentLabel:"Nombre actuel",mortBtn:"Calculer la mortalité",historyTitle:"Historique",historyDesc:"Derniers calculs enregistrés sur l’appareil.",clear:"Effacer l’historique",settingsTitle:"Paramètres",settingsDesc:"Personnalisez l’application.",languageLabel:"Langue",version:"Version 1.0.0",offline:"Fonctionne hors ligne après installation",navHome:"Accueil",navCalc:"Calcul",navHistory:"Historique",navSettings:"Paramètres",bags:"Poches nécessaires",tables:"Tables nécessaires",capacity:"Capacité d’une table",lost:"Huîtres perdues",rate:"Taux de mortalité",saved:"Opération enregistrée",empty:"Aucune opération enregistrée.",confirm:"Effacer l’historique ?"},
en:{subtitle:"Oyster farm management",welcome:"Dashboard",heroText:"Simple and fast management for oyster farming.",statOystersLabel:"Current oysters",statBagsLabel:"Required bags",statTablesLabel:"Required tables",statMortLabel:"Mortality",goCalc:"Calculator",goCalcSub:"Bags and tables",goMort:"Mortality",goMortSub:"Losses and rate",goHistory:"History",goHistorySub:"Recent operations",goSettings:"Settings",goSettingsSub:"Language and interface",calcTitle:"Distribution calculator",calcDesc:"Calculate required bags and tables.",oystersLabel:"Remaining oysters",bagLabel:"Oysters per bag",tableLabel:"Bags per table",calcBtn:"Calculate",mortTitle:"Mortality calculator",mortDesc:"Calculate losses and mortality rate.",initialLabel:"Initial count",currentLabel:"Current count",mortBtn:"Calculate mortality",historyTitle:"History",historyDesc:"Recent calculations saved on this device.",clear:"Clear history",settingsTitle:"Settings",settingsDesc:"Customize the app.",languageLabel:"Language",version:"Version 1.0.0",offline:"Works offline after installation",navHome:"Home",navCalc:"Calculate",navHistory:"History",navSettings:"Settings",bags:"Required bags",tables:"Required tables",capacity:"Table capacity",lost:"Lost oysters",rate:"Mortality rate",saved:"Operation saved",empty:"No saved operations.",confirm:"Clear history?"}
};
function tr(k){return t[state.lang][k]||k}
function fmt(n){return new Intl.NumberFormat(state.lang==="ar"?"ar-MA":state.lang==="fr"?"fr-FR":"en-US").format(n)}
function showScreen(id){
  $$(".screen").forEach(x=>x.classList.toggle("active",x.id===id));
  $$(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.screen===id));
  window.scrollTo(0,0);
}
function saveHistory(item){state.history.unshift({...item,date:new Date().toISOString()});state.history=state.history.slice(0,30);localStorage.setItem("ofm_history",JSON.stringify(state.history));renderHistory();}
function renderHistory(){
  const box=$("#historyList");
  if(!state.history.length){box.innerHTML=`<div class="card">${tr("empty")}</div>`;return}
  box.innerHTML=state.history.map(h=>`<div class="history-item"><time>${new Date(h.date).toLocaleString(state.lang==="ar"?"ar-MA":state.lang==="fr"?"fr-FR":"en-US")}</time><strong>${h.type==="calc"?"🧮 "+tr("goCalc"):"📉 "+tr("goMort")}</strong><div>${h.text}</div></div>`).join("");
}
function applyLanguage(){
  document.documentElement.lang=state.lang;document.documentElement.dir=state.lang==="ar"?"rtl":"ltr";
  const keys=["subtitle","welcome","heroText","statOystersLabel","statBagsLabel","statTablesLabel","statMortLabel","goCalc","goCalcSub","goMort","goMortSub","goHistory","goHistorySub","goSettings","goSettingsSub","calcTitle","calcDesc","oystersLabel","bagLabel","tableLabel","mortTitle","mortDesc","initialLabel","currentLabel","historyTitle","historyDesc","settingsTitle","settingsDesc","languageLabel","version","offline","navHome","navCalc","navHistory","navSettings"];
  keys.forEach(k=>{const el=document.getElementById(k);if(el)el.textContent=tr(k)});
  $("#calculateBtn").textContent=tr("calcBtn");$("#mortalityBtn").textContent=tr("mortBtn");$("#clearHistory").textContent=tr("clear");
  $("#language").value=state.lang;renderHistory();updateDashboard();
}
function updateDashboard(){
  const d=JSON.parse(localStorage.getItem("ofm_dashboard")||"{}");
  $("#statOysters").textContent=fmt(d.oysters||0);$("#statBags").textContent=fmt(d.bags||0);$("#statTables").textContent=fmt(d.tables||0);$("#statMort").textContent=(d.mortality||0)+"%";
}
function calc(){
  const oysters=Number($("#oysters").value), bag=Number($("#bagCapacity").value), perTable=Number($("#bagsPerTable").value);
  if(!(oysters>=0&&bag>0&&perTable>0))return alert(state.lang==="ar"?"أدخل القيم بشكل صحيح.":state.lang==="fr"?"Saisissez des valeurs valides.":"Enter valid values.");
  const bags=Math.ceil(oysters/bag),tables=Math.ceil(bags/perTable);
  $("#calcResult").classList.remove("hidden");
  $("#calcResult").innerHTML=`<div class="result-grid"><div class="result-item"><small>${tr("bags")}</small><b>${fmt(bags)}</b></div><div class="result-item"><small>${tr("tables")}</small><b>${fmt(tables)}</b></div><div class="result-item"><small>${tr("capacity")}</small><b>${fmt(bag*perTable)}</b></div></div>`;
  localStorage.setItem("ofm_dashboard",JSON.stringify({oysters,bags,tables,mortality:JSON.parse(localStorage.getItem("ofm_dashboard")||"{}").mortality||0}));
  saveHistory({type:"calc",text:`${fmt(oysters)} 🦪 → ${fmt(bags)} 👜 → ${fmt(tables)} 🪜`});updateDashboard();
}
function mortality(){
  const initial=Number($("#initialOysters").value), current=Number($("#currentOysters").value);
  if(!(initial>0&&current>=0&&current<=initial))return alert(state.lang==="ar"?"تحقق من الأعداد.":state.lang==="fr"?"Vérifiez les nombres.":"Check the numbers.");
  const lost=initial-current, rate=Math.round((lost/initial)*10000)/100;
  $("#mortResult").classList.remove("hidden");
  $("#mortResult").innerHTML=`<div class="result-grid"><div class="result-item"><small>${tr("lost")}</small><b>${fmt(lost)}</b></div><div class="result-item"><small>${tr("rate")}</small><b>${rate}%</b></div></div>`;
  const d=JSON.parse(localStorage.getItem("ofm_dashboard")||"{}");d.oysters=current;d.mortality=rate;localStorage.setItem("ofm_dashboard",JSON.stringify(d));saveHistory({type:"mort",text:`${fmt(initial)} → ${fmt(current)} | ${fmt(lost)} | ${rate}%`});updateDashboard();
}
$$("[data-screen]").forEach(b=>b.addEventListener("click",()=>showScreen(b.dataset.screen)));
$("#calculateBtn").addEventListener("click",calc);$("#mortalityBtn").addEventListener("click",mortality);
$("#clearHistory").addEventListener("click",()=>{if(confirm(tr("confirm"))){state.history=[];localStorage.removeItem("ofm_history");renderHistory()}});
$("#language").addEventListener("change",e=>{state.lang=e.target.value;localStorage.setItem("ofm_lang",state.lang);applyLanguage()});
$("#themeBtn").addEventListener("click",()=>{state.dark=!state.dark;document.body.classList.toggle("dark",state.dark);localStorage.setItem("ofm_dark",state.dark?"1":"0")});
document.body.classList.toggle("dark",state.dark);applyLanguage();

# Oyster Farm Manager

PWA لإدارة وحسابات مزرعة المحار.

## المزايا
- العربية / Français / English
- حساب الجيوب والطاولات
- حساب نسبة النفوق
- حفظ محلي للبيانات
- PWA والعمل دون إنترنت بعد أول تحميل
- مناسب للآيفون وإضافة إلى الشاشة الرئيسية

## GitHub Pages
فعّل Pages من:
Settings → Pages → Deploy from a branch → main → / (root)

ثم افتح رابط GitHub Pages على Safari واختر Share → Add to Home Screen.

## ملاحظة
لا يحتوي الإصدار 1.0 على العملة أو الترقيم التلقائي للجيوب والطاولات.
